<?php
namespace Sample\iTop\Extension\Service;

class MyService
{

}