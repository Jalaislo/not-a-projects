# Extension Extention that chages portal logo

Для смены логотипа на пользовательском портале заменить файл логотипа-заглушки:

	/assets/img/custom_portal_logo.png		- Логотип на пользовательском портале