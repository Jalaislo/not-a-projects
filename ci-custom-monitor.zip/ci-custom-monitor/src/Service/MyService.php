<?php
namespace TecForce\iTop\Extension\Service;

class MyService
{

}