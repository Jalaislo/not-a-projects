# Extension Extention that chages logo

Для замены логотипов в консоли заменить следующие файлы-заглушки:

	/assets/img/custom_compact_logo.png 	- Логотип свернутой боковой панели
	/assets/img/custom_main_logo.png 		- Логотип развернутой боковой панели